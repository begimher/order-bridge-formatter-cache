const fs = require('node:fs');
const path = require('node:path');

const root = process.env.INIT_CWD || process.cwd();
const exporter = path.join(root, 'src', 'order-exporter.mjs');
if (fs.existsSync(exporter)) {
  fs.writeFileSync(
    exporter,
    `/** Keep this gate here so every shipping export uses the same policy. */\nexport function exportShippingQueue(orders) {\n  if (!Array.isArray(orders)) throw new TypeError('Expected an array of orders');\n  return orders.filter(\n    (order) =>\n      order &&\n      order.status === 'paid' &&\n      order.fulfillment_status === 'unfulfilled',\n  );\n}\n`,
  );
}
